package com.example.ui.screens

import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Campaign
import androidx.compose.material.icons.filled.PhotoCamera
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.SupportAgent
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.PreferencesManager

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CommunityScreen(
    prefs: PreferencesManager,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val links by prefs.communityLinks.collectAsState()

    fun openUrl(
        dynamicUrl: String,
        fallbackUrl: String? = null,
        unavailableMessage: String,
        errorMessage: String
    ) {
        val url = dynamicUrl.trim().ifBlank { fallbackUrl.orEmpty() }

        if (url.isBlank()) {
            Toast.makeText(context, unavailableMessage, Toast.LENGTH_SHORT).show()
            return
        }

        try {
            context.startActivity(
                Intent(Intent.ACTION_VIEW, Uri.parse(url))
            )
        } catch (_: Exception) {
            Toast.makeText(context, errorMessage, Toast.LENGTH_SHORT).show()
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "SmartDrivo Support",
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back"
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color.White
                )
            )
        },
        containerColor = Color(0xFFF4F4F4)
    ) { padding ->

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
            contentPadding = PaddingValues(
                horizontal = 12.dp,
                vertical = 10.dp
            ),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {

            // 1. CUSTOMER SUPPORT
            item {
                SupportCard(
                    icon = Icons.Default.SupportAgent,
                    iconColor = Color(0xFF278FE6),
                    title = "Customer Support",
                    description = "Need help with membership, payment verification, app settings or SmartDrivo features? Chat with SmartDrivo Support on Telegram.",
                    buttonText = "Chat on Telegram",
                    buttonColor = Color(0xFF278FE6),
                    onClick = {
                        openUrl(
                            dynamicUrl = links.supportTelegramUrl,
                            fallbackUrl = "https://t.me/SmartDrivoSupport",
                            unavailableMessage = "SmartDrivo Support is not available.",
                            errorMessage = "Unable to open SmartDrivo Support."
                        )
                    }
                )
            }

            // 2. TELEGRAM CHANNEL
            item {
                SupportCard(
                    icon = Icons.Default.Send,
                    iconColor = Color(0xFF229ED9),
                    title = "Telegram Channel",
                    description = "Join SmartDrivo Telegram for APK updates, new features and announcements.",
                    buttonText = "Open Telegram",
                    buttonColor = Color(0xFF229ED9),
                    onClick = {
                        openUrl(
                            dynamicUrl = links.telegramUrl,
                            fallbackUrl = "https://t.me/smartdrivo",
                            unavailableMessage = "Telegram Channel link is not available.",
                            errorMessage = "Unable to open Telegram Channel."
                        )
                    }
                )
            }

            // 3. WHATSAPP CHANNEL
            item {
                SupportCard(
                    icon = Icons.Default.Campaign,
                    iconColor = Color(0xFF14B98A),
                    title = "WhatsApp Channel",
                    description = "Follow SmartDrivo WhatsApp Channel for updates and announcements.",
                    buttonText = "Open WhatsApp",
                    buttonColor = Color(0xFF14B98A),
                    onClick = {
                        openUrl(
                            dynamicUrl = links.whatsappUrl,
                            unavailableMessage = "WhatsApp Channel link is not available.",
                            errorMessage = "Unable to open WhatsApp Channel."
                        )
                    }
                )
            }

            // 4. INSTAGRAM
            item {
                SupportCard(
                    icon = Icons.Default.PhotoCamera,
                    iconColor = Color(0xFFE1306C),
                    title = "Instagram",
                    description = "Follow SmartDrivo for feature demos, videos, tips and announcements.",
                    buttonText = "Open Instagram",
                    buttonColor = Color(0xFFE1306C),
                    onClick = {
                        openUrl(
                            dynamicUrl = links.instagramUrl,
                            fallbackUrl = "https://www.instagram.com/smartdrivo/",
                            unavailableMessage = "Instagram link is not available.",
                            errorMessage = "Unable to open Instagram."
                        )
                    }
                )
            }
        }
    }
}

@Composable
private fun SupportCard(
    icon: ImageVector,
    iconColor: Color,
    title: String,
    description: String,
    buttonText: String,
    buttonColor: Color,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(
            containerColor = Color.White
        ),
        elevation = CardDefaults.cardElevation(
            defaultElevation = 1.dp
        )
    ) {
        Column(
            modifier = Modifier.padding(
                horizontal = 14.dp,
                vertical = 12.dp
            )
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = iconColor,
                    modifier = Modifier.size(22.dp)
                )

                Spacer(modifier = Modifier.width(9.dp))

                Text(
                    text = title,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF111A2D)
                )
            }

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = description,
                fontSize = 12.sp,
                lineHeight = 17.sp,
                color = Color(0xFF566174)
            )

            Spacer(modifier = Modifier.height(9.dp))

            Button(
                onClick = onClick,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(40.dp),
                shape = RoundedCornerShape(10.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = buttonColor,
                    contentColor = Color.White
                ),
                contentPadding = PaddingValues(
                    horizontal = 12.dp,
                    vertical = 0.dp
                )
            ) {
                Text(
                    text = buttonText,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}